package path;

public class MyCommon {
	
	public static final String PATH = "/WEB-INF/views/main/"; // 메인페이지
	
	public static final String LOGIN_PATH = "/WEB-INF/views/login/"; // 로그인페이지
	
	public static final String BOARD_PATH = "/WEB-INF/views/board/"; // 게시판페이지
	
	public static final String FRAME_PATH = "/WEB-INF/views/frame/"; // 프레임페이지
	
	public static final String INTRO_PATH = "/WEB-INF/views/intro/"; // 인트로페이지
}
