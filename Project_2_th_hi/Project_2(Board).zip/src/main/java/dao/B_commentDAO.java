package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.B_commentVO;

public class B_commentDAO {
	SqlSession sqlSession;
	
	public B_commentDAO(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public int insert(B_commentVO vo) {
		int res = sqlSession.insert("bc.insert", vo);
		return res;
	}
	
	public List<B_commentVO> selectboard_id(int board_id) {
		List<B_commentVO> list = new ArrayList<B_commentVO>();
		list = sqlSession.selectList("bc.selectboard_id", board_id);
//		for(int i=0; i<list.size(); i++) {
//			System.out.println(list.get(i).getContent());
//		}
		return list;
	}
}
