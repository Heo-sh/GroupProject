package vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Brand_nameVO {
	private int brand_num; //브랜드 관리를 위한 번호
	private String brand_name; //브랜드 명
}
