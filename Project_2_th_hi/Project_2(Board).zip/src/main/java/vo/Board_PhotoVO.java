package vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Board_PhotoVO {
	private int board_id;
	private String content;
	private String date;
	private int like_b;
	private String nickname;
	private String ip;
	private int brand_num;
	private String photo_name;
	private int photp_num;
	private String photo_regi;
}	
