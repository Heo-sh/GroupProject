package path;

public class MyCommon {
	
	public static final String PATH = "/WEB-INF/views/";
	
	/* public static final String MAIN_PATH = "/WEB-INF/views/main/"; */

	//게시판 경로
	public static final String BOARD_PATH = "/WEB-INF/views/board/";
}
