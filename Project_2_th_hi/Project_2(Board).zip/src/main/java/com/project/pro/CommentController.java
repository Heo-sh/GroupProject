package com.project.pro;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import dao.B_commentDAO;
import dao.ProMemberDAO;
import vo.B_commentVO;
import vo.ProMemberVO;

@Controller
public class CommentController {
	B_commentDAO comment_dao;
	
	ProMemberDAO proMember_dao;
	
	@Autowired
	HttpServletRequest request;
	
	public CommentController(B_commentDAO comment_dao, ProMemberDAO proMember_dao) {
		this.comment_dao = comment_dao;
		this.proMember_dao = proMember_dao;
	}
	
	//댓글 달기
	@RequestMapping("reply")
	@ResponseBody
	public String reply(String nickname, int board_id, String content, HttpServletRequest request) {		
		//ip 가져오기
		String ip = request.getRemoteAddr();;
		
		B_commentVO vo = new B_commentVO();
		vo.setNickname(nickname);
		vo.setBoard_id(board_id);
		vo.setContent(content);
		vo.setIp(ip);
		
		int res = comment_dao.insert(vo);
		
		if (res > 0) {
			return "[{'result' : 'yes'}]"; 
		}
		return "[{'result' : 'no'}]";
	}
	
}
